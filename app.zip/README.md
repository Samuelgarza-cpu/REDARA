PRIMER COMMIT

#ComandosIniciales
-composer install
-npm install
-npm run build
-composer run dev
-php artisan storage:link
-php artisan lang:publish
-npm install @google-cloud/vision
-npm install --save-dev @types/react-input-mask
-import InputMask from 'react-input-mask';
-npm install react-input-mask -- ESTE YA NO SIRVE SE INSTALA ESTE npm install react-input-mask-next
-import InputMask from 'react-input-mask-next';



https://www.php.net/manual/es/timezones.america.php // para cambiar la zona horaria
#PaginasNecesarias
-Iconos
https://lucide.dev/icons

-Componentes
https://ui.shadcn.com/
