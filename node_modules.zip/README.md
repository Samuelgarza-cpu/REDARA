PRIMER COMMIT

#ComandosIniciales
-composer install
-npm install
-npm run build
-composer run dev
-php artisan storage:link
-php artisan lang:publish
-npm install @google-cloud/vision

https://www.php.net/manual/es/timezones.america.php // para cambiar la zona horaria
#PaginasNecesarias
-Iconos
https://lucide.dev/icons

-Componentes
https://ui.shadcn.com/
